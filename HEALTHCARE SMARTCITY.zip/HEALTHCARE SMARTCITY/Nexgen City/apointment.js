// Data
const registeredCitizens = [
    { name: 'Nihal Karkera', citizenId: 'CIT123' },
    { name: 'Sanjay Moolya', citizenId: 'CIT124' },
    { name: 'Rithvik', citizenId: 'CIT125' },
    { name: 'Shivanandu', citizenId: 'CIT126' }
];

const hospitalDetails = {
    'HOSP123': { name: 'Sato Hospital', specialization: 'General Physician' },
    'HOSP134': { name: 'NexGen Gov Hospital', specialization: 'General Physician' },
    'HOSP145': { name: 'General Clinic', specialization: 'Orthopedic' },
    'HOSP156': { name: 'Alpha Hospital', specialization: 'Cardiologist' },
    'HOSP167': { name: 'City Hospital', specialization: 'Ear-otolaryngologist' },
    'HOSP178': { name: 'Government Hospital 1', specialization: 'ophthalmologist' },
    'HOSP189': { name: 'Government Hospital 2', specialization: 'Neurologist' },
    'HOSP191': { name: 'Government Hospital 3', specialization: 'Dermatologist' },
    'HOSP195': { name: 'Government Hospital 4', specialization: 'Endocrinologist' }
};

const hospitalSpecializations = {
    "General Physician": ['HOSP123', 'HOSP134'],
    "Orthopedic": ['HOSP145'],
    "Cardiologist": ['HOSP156'],
    "Dermatologist": ['HOSP191'],
    "Neurologist": ['HOSP189'],
    "Ear-otolaryngologist": ['HOSP167'],
    "ophthalmologist": ['HOSP178'],
    "Endocrinologist": ['HOSP195']
};

// Appointments Array
const appointments = [];

// Function to handle appointment booking
document.getElementById('appointmentForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const citizenId = document.getElementById('citizenId').value;
    const date = document.getElementById('date').value;
    const doctorType = document.getElementById('doctorType').value;

    // Check if citizen is registered
    const citizen = registeredCitizens.find(citizen => citizen.name === name && citizen.citizenId === citizenId);

    if (!citizen) {
        alert('Citizen not registered. Please check your details.');
        return;
    }

    // Find a hospital specializing in the selected doctor type
    const hospitals = hospitalSpecializations[doctorType];
    if (!hospitals) {
        alert('Invalid doctor type selected.');
        return;
    }

    const randomHospitalId = hospitals[Math.floor(Math.random() * hospitals.length)];
    const hospitalName = hospitalDetails[randomHospitalId].name;
    const appointmentTime = '10:00 AM'; // Dummy time for now

    const appointment = {
        name,
        citizenId,
        date,
        doctorType,
        appointmentTime,
        hospitalId: randomHospitalId,
        hospitalName
    };

    appointments.push(appointment);

    document.getElementById('confirmationMessage').innerText = `Appointment booked successfully for ${name} at ${hospitalName} (${randomHospitalId})!`;
});
