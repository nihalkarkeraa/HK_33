const doctors = {
    'DR001': { firstName: 'Sam', lastName: 'Walt', specialization: 'General Physician', phone: '1234567890', email: 'sam.walt@example.com', hospID: 'HOSP123' },
    'DR002': { firstName: 'William', lastName: 'Brown', specialization: 'General Physician', phone: '2345678901', email: 'william.brown@example.com', hospID: 'HOSP134' },
    'DR003': { firstName: 'Radha', lastName: 'Kumari', specialization: 'Orthopedic', phone: '3456789012', email: 'radha.kumari@example.com', hospID: 'HOSP145' },
    'DR004': { firstName: 'Lee', lastName: 'Wan', specialization: 'Cardiologist', phone: '4567890123', email: 'lee.wan@example.com', hospID: 'HOSP156' },
    'DR005': { firstName: 'Brooklyn', lastName: 'Smith', specialization: 'otolaryngologist', phone: '5678901234', email: 'brooklyn@example.com', hospID: 'HOSP167' },
    'DR006': { firstName: 'Alex', lastName: 'Ellenois', specialization: 'ophthalmologist', phone: '6789012345', email: 'alex.ellen@example.com', hospID: 'HOSP178' },
    'DR007': { firstName: 'Jake', lastName: 'Donald', specialization: 'Dermatologist', phone: '7890123456', email: 'jake.donald@example.com', hospID: 'HOSP191' },
    'DR008': { firstName: 'Banu', lastName: 'Kumar', specialization: 'Neurologist', phone: '8901234567', email: 'banu.kumar@example.com', hospID: 'HOSP189' },
    'DR009': { firstName: 'Ashok', lastName: 'Kumar', specialization: 'Endocrinologist', phone: '9012345678', email: 'ashok.kumar@example.com', hospID: 'HOSP195' },
};

function login() {
    const doctorID = document.getElementById('doctorID').value.trim();
    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const specialization = document.getElementById('specialization').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const email = document.getElementById('email').value.trim();

    const doctor = doctors[doctorID];

    if (
        doctor && 
        doctor.firstName === firstName && 
        doctor.lastName === lastName &&
        doctor.specialization === specialization &&
        doctor.phone === phone &&
        doctor.email === email
    ) {
        // Hide error message
        document.getElementById('error').style.display = 'none';

        // Redirect to prescribe page with doctor ID
        window.location.href = `prescribe.html?doctorID=${doctorID}`;
    } else {
        // Show error message
        document.getElementById('error').style.display = 'block';
    }
}