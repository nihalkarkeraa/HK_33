// Dummy database of citizens with additional health metrics
const citizens = [
    { 
        name: 'Nihal', 
        citizenId: 'CIT001', 
        details: {
            description: 'Details about Nihal, including health and other records.',
            bloodSugar: '110 mg/dL', 
            bpm: '72 bpm', 
            oxygen: '98%'
        }
    },
    { 
        name: 'Ravi', 
        citizenId: 'CIT002', 
        details: {
            description: 'Details about Ravi, including health and other records.',
            bloodSugar: '105 mg/dL', 
            bpm: '75 bpm', 
            oxygen: '97%'
        }
    },
    { 
        name: 'Priya', 
        citizenId: 'CIT003', 
        details: {
            description: 'Details about Priya, including health and other records.',
            bloodSugar: '115 mg/dL', 
            bpm: '70 bpm', 
            oxygen: '99%'
        }
    },
    { 
        name: 'Amit', 
        citizenId: 'CIT004', 
        details: {
            description: 'Details about Amit, including health and other records.',
            bloodSugar: '120 mg/dL', 
            bpm: '80 bpm', 
            oxygen: '96%'
        }
    },
    { 
        name: 'Suman', 
        citizenId: 'CIT005', 
        details: {
            description: 'Details about Suman, including health and other records.',
            bloodSugar: '100 mg/dL', 
            bpm: '78 bpm', 
            oxygen: '95%'
        }
    }
];

// Function to handle login form submission
document.getElementById('loginForm').addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent the form from submitting in the traditional way

    const name = document.getElementById('name').value.trim();
    const citizenId = document.getElementById('citizenId').value.trim();

    // Find the citizen in the database
    const citizen = citizens.find(citizen => citizen.name === name && citizen.citizenId === citizenId);

    const userDetailsDiv = document.getElementById('userDetails');

    if (citizen) {
        // Show the details if the citizen is found
        userDetailsDiv.innerHTML = `
            <p>${citizen.details.description}</p>
            <p>Previous records are:</p>
            <p><strong>Blood Sugar:</strong> ${citizen.details.bloodSugar}</p>
            <p><strong>BPM:</strong> ${citizen.details.bpm}</p>
            <p><strong>Oxygen Level:</strong> ${citizen.details.oxygen}</p>
        `;
        userDetailsDiv.classList.remove('hidden1'); // Make the details visible
    } else {
        // Show an error message if the login fails
        userDetailsDiv.innerHTML = `<p class="error">Invalid Name or Citizen ID. Please try again.</p>`;
        userDetailsDiv.classList.remove('hidden1');
    }
});
