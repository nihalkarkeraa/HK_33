// Appointments Array (should be imported or fetched from a database in a real application)
const appointments = [
    // Example appointments
    {
        name: 'Nihal Karkera',
        citizenId: 'CIT123',
        date: '2024-09-15',
        doctorType: 'General Physician',
        appointmentTime: '10:00 AM',
        hospitalId: 'HOSP123',
        hospitalName: 'Sato Hospital'
    }
];

// Function to view appointments by Hospital ID
function viewAppointments() {
    const hospitalIdInput = document.getElementById('hospitalId').value;
    const appointmentsContainer = document.getElementById('appointmentsContainer');

    // Clear previous results
    appointmentsContainer.innerHTML = '';

    // Filter appointments for the entered Hospital ID
    const hospitalAppointments = appointments.filter(
        appointment => appointment.hospitalId === hospitalIdInput
    );

    if (hospitalAppointments.length === 0) {
        appointmentsContainer.innerHTML = '<p>No appointments found for this hospital.</p>';
        return;
    }

    // Display the appointments
    hospitalAppointments.forEach(appointment => {
        const appointmentDiv = document.createElement('div');
        appointmentDiv.innerHTML = `
            <p><strong>Citizen Name:</strong> ${appointment.name}</p>
            <p><strong>Citizen ID:</strong> ${appointment.citizenId}</p>
            <p><strong>Appointment Date:</strong> ${appointment.date}</p>
            <p><strong>Doctor Type:</strong> ${appointment.doctorType}</p>
            <p><strong>Appointment Time:</strong> ${appointment.appointmentTime}</p>
            <p><strong>Hospital:</strong> ${appointment.hospitalId} (${appointment.hospitalName})</p>
            <hr>
        `;
        appointmentsContainer.appendChild(appointmentDiv);
    });
}
