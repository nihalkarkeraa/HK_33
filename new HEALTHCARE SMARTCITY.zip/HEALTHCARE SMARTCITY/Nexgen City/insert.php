<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = ""; // Your MySQL password, if any
$dbname = "rfid_health_db"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['remarks'])) {
    // Retrieve and sanitize form data
    $remarks = $_POST['remarks'];
    $id = intval($_POST['id']); // Ensure the ID is an integer

    // Prepare and bind
    $stmt = $conn->prepare("UPDATE rfid_records SET remarks = ? WHERE id = ?");
    $stmt->bind_param("si", $remarks, $id); // 'si' indicates the types of the parameters (string, integer)

    // Execute
    if ($stmt->execute()) {
        echo "<p>Record updated successfully</p>";
    } else {
        echo "<p>Error: " . $stmt->error . "</p>";
    }

    // Close statement
    $stmt->close();
}

// Query to select data from the table
$sql = "SELECT id, rfid_tag_id, timestamp, patent_name, hospital_id, remarks FROM rfid_records";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prescription</title>
    <link rel="stylesheet" href="insert.css">
</head>
<body>
    <h1>Database Records</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th> <!-- ID column -->
                <th>RFID</th> <!-- RFID column -->
                <th>Time Stamp</th> <!-- Time Stamp column -->
                <th>Patient Name</th> <!-- Patent Name column -->
                <th>Hospital ID</th> <!-- Hospital ID column -->
                <th>Remarks</th> <!-- Remarks column -->
            </tr>
        </thead>
        
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row["id"]) . "</td>"; // Display ID
                    echo "<td>" . htmlspecialchars($row["rfid_tag_id"]) . "</td>"; // Display RFID
                    echo "<td>" . htmlspecialchars($row["timestamp"]) . "</td>"; // Display Time Stamp
                    echo "<td>" . htmlspecialchars($row["patent_name"]) . "</td>"; // Display Patent Name
                    echo "<td>" . htmlspecialchars($row["hospital_id"]) . "</td>"; // Display Hospital ID
                    echo "<td>" . htmlspecialchars($row["remarks"]) . "</td>"; // Display Remarks
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No records found</td></tr>"; // Adjusted colspan for new columns
            }
            ?>
        </tbody>
    </table>
    
    <!-- Form for adding remarks -->
    <h2>Add Remarks</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="id">Record ID:</label>
        <input type="text" id="id" name="id" required>
        <br><br>
        
        <label for="remarks">Remarks:</label>
        <textarea id="remarks" name="remarks" rows="4" cols="50" required></textarea>
        <br><br>
        
        <input type="submit" value="Add Remark">
    </form>

    <?php
    // Close connection
    $conn->close();
    ?>
</body>
</html>
